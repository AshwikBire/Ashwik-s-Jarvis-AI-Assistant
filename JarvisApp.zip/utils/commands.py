import datetime
import webbrowser

def handle_command(command):
    command = command.lower()

    if "time" in command:
        now = datetime.datetime.now().strftime("%I:%M %p")
        return f"The time is {now}"

    elif "date" in command:
        today = datetime.datetime.now().strftime("%A, %d %B %Y")
        return f"Today is {today}"

    elif "open youtube" in command:
        webbrowser.open("https://www.youtube.com")
        return "Opening YouTube"

    elif "open google" in command:
        webbrowser.open("https://www.google.com")
        return "Opening Google"

    elif "file" in command:
        return "You can integrate file management here."

    elif "shutdown" in command:
        return "Shutting down... Bye!"

    else:
        return "Sorry, I don't understand that command yet."
