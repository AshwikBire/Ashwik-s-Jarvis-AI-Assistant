import streamlit as st
from utils.voice import listen, speak
from utils.commands import handle_command
from PIL import Image
import datetime

# Set Streamlit page config
st.set_page_config(page_title="🧠 Jarvis - Offline AI Assistant", layout="centered", page_icon="🤖")

# Load logo/image
st.markdown("""
    <style>
    body { background-color: #0E1117; color: #FAFAFA; }
    h1 { color: #00FFAA; }
    .stButton>button {
        background-color: #262730;
        color: #00FFAA;
        border: 1px solid #00FFAA;
        border-radius: 12px;
    }
    </style>
""", unsafe_allow_html=True)

st.markdown("<h1 style='text-align: center;'>🧠 Jarvis - Your AI Assistant</h1>", unsafe_allow_html=True)
img = Image.open("assets/logo.png")
st.image(img, width=200)

# Input method
input_method = st.radio("Choose Input Method:", ["🎙️ Voice", "⌨️ Text"])

if input_method == "⌨️ Text":
    user_input = st.text_input("Type your command")
    if st.button("Run Command"):
        response = handle_command(user_input)
        st.success(response)
        speak(response)

else:
    if st.button("🎧 Start Listening"):
        st.info("Listening...")
        text = listen()
        st.write(f"You said: `{text}`")
        response = handle_command(text)
        st.success(response)
        speak(response)

# Footer
st.markdown("<hr>", unsafe_allow_html=True)
st.markdown("<p style='text-align: center;'>Made with ❤️ by Ashwik</p>", unsafe_allow_html=True)
